use std::collections::HashMap;
use std::sync::Arc;
use async_trait::async_trait;
use serde_json::Value;
use tokio::sync::Mutex as AMutex;
use tokio::process::Command;

use crate::at_commands::at_commands::AtCommandsContext;
use crate::tools::tools_description::{Tool, ToolDesc, ToolParam, ToolSource, ToolSourceType};
use crate::call_validation::{ChatMessage, ChatContent, ContextEnum};

use super::config::ESP32Config;
use super::output_protocol::{ToolOutput, ToolStatus};
use super::idf_command::IdfCommand;
use super::global_state::{get_config, generate_suggested_actions, SuggestionContext};

pub struct ESP32Project {
    pub config_path: String,
}

#[async_trait]
impl Tool for ESP32Project {
    fn as_any(&self) -> &dyn std::any::Any { self }

    fn tool_description(&self) -> ToolDesc {
        ToolDesc {
            name: "esp32_project".to_string(),
            display_name: "ESP32 Project".to_string(),
            source: ToolSource {
                source_type: ToolSourceType::Builtin,
                config_path: self.config_path.clone(),
            },
            agentic: true,
            experimental: false,
            description: "Manage ESP32 projects. Operations: 'create' (create new project from template/example), 'validate' (validate project structure). IMPORTANT: Do NOT guess the template path — wrong guesses waste turns. Real IDF v5.5 example paths: 'get-started/blink', 'get-started/hello_world', 'provisioning/wifi_prov_mgr', 'wifi/getting_started/station', 'bluetooth/bluedroid/ble/gatt_server', 'mqtt/tcp'. If unsure of the exact path, use search_pattern(pattern='<keyword>', scope='esp-idf-release-v5.5/examples') to discover it BEFORE calling create. Do NOT fall back to shell commands (cp, mkdir, etc.) to create projects manually.".to_string(),
            parameters: vec![
                ToolParam {
                    name: "operation".to_string(),
                    param_type: "string".to_string(),
                    description: "Operation: 'create' (create new project from template/example), 'validate' (validate project structure)".to_string(),
                },
                ToolParam {
                    name: "project_name".to_string(),
                    param_type: "string".to_string(),
                    description: "Project name (required for 'create')".to_string(),
                },
                ToolParam {
                    name: "template".to_string(),
                    param_type: "string".to_string(),
                    description: "Template/example path relative to $IDF_PATH/examples (e.g., 'get-started/blink', 'provisioning/wifi_prov_mgr'). Search first if you are not sure of the exact path.".to_string(),
                },
                ToolParam {
                    name: "target".to_string(),
                    param_type: "string".to_string(),
                    description: "Target chip: esp32, esp32s3, esp32c3, esp32c6, esp32p4 (default: from config)".to_string(),
                },
                ToolParam {
                    name: "project_path".to_string(),
                    param_type: "string".to_string(),
                    description: "Path to project (for 'validate')".to_string(),
                },
            ],
            parameters_required: vec!["operation".to_string()],
        }
    }

    async fn tool_execute(
        &mut self,
        ccx: Arc<AMutex<AtCommandsContext>>,
        tool_call_id: &String,
        args: &HashMap<String, Value>,
    ) -> Result<(bool, Vec<ContextEnum>), String> {
        let operation = args.get("operation")
            .and_then(|v| v.as_str())
            .ok_or("Missing required parameter: operation")?;

        // Use global config (cached, configurable via env var)
        let config = get_config().await?;
        config.validate_paths()?;

        let output = match operation {
            "create" => self.create_project(&config, args).await?,
            "validate" => self.validate_project(&config, args).await?,
            _ => return Err(format!("Unknown operation: '{}'. Valid operations: 'create', 'validate'.", operation)),
        };

        let context_files = vec![ContextEnum::ChatMessage(ChatMessage {
            role: "tool".to_string(),
            content: ChatContent::SimpleText(output.to_llm_context()),
            tool_calls: None,
            tool_call_id: tool_call_id.clone(),
            ..Default::default()
        })];

        Ok((false, context_files))
    }

    fn tool_depends_on(&self) -> Vec<String> {
        vec!["esp32".to_string()]
    }
}

impl ESP32Project {
    async fn create_project(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        let project_name = args.get("project_name")
            .and_then(|v| v.as_str())
            .ok_or("Missing required parameter: project_name for 'create' operation")?;

        let template = args.get("template")
            .and_then(|v| v.as_str())
            .unwrap_or("get-started/blink");

        let target = args.get("target")
            .and_then(|v| v.as_str())
            .unwrap_or(&config.default_target);

        let project_path = std::path::PathBuf::from(&config.projects_path).join(project_name);

        // Ensure projects directory exists
        std::fs::create_dir_all(&config.projects_path)
            .map_err(|e| format!("Failed to create projects directory: {}", e))?;

        // Check if project already exists
        if project_path.exists() {
            return Err(format!("Project '{}' already exists at {}", project_name, project_path.display()));
        }

        // If template contains '/', it's an example path - use create-project-from-example
        if template.contains('/') {
            // Use idf.py create-project-from-example (ESP-IDF v5.0+)
            let example_full_path = format!("examples/{}", template);

            let result = IdfCommand::new("create-project-from-example")
                .arg(&example_full_path)
                .project_path(std::path::Path::new(&config.projects_path))
                .timeout_secs(120)
                .execute(config).await?;

            if !result.success {
                // Fallback: try copying the example manually
                let example_path = std::path::PathBuf::from(&config.esp_idf_path)
                    .join("examples")
                    .join(template);

                if example_path.exists() {
                    let mut copy_cmd = Command::new("cp");
                    let example_str = example_path.to_string_lossy();
                    let project_str = project_path.to_string_lossy();
                    copy_cmd.args(&["-r", &example_str, &project_str]);
                    let copy_result = copy_cmd.output().await
                        .map_err(|e| format!("Failed to copy example: {}", e))?;

                    if !copy_result.status.success() {
                        return Err(format!("Project creation failed: {}", result.combined_output()));
                    }
                } else {
                    return Err(format!(
                        "Example '{}' not found. Use search_semantic to discover available examples.",
                        template
                    ));
                }
            }

            // Rename the created project folder if needed (create-project-from-example uses example name)
            let example_name = template.split('/').last().unwrap_or(template);
            let created_path = std::path::PathBuf::from(&config.projects_path).join(example_name);
            if created_path.exists() && created_path != project_path {
                std::fs::rename(&created_path, &project_path)
                    .map_err(|e| format!("Failed to rename project: {}", e))?;
            }
        } else {
            // Create empty project with idf.py create-project
            let result = IdfCommand::new("create-project")
                .arg(project_name)
                .project_path(std::path::Path::new(&config.projects_path))
                .timeout_secs(60)
                .execute(config).await?;

            if !result.success {
                return Err(format!("Project creation failed: {}", result.stderr));
            }
        }

        // Set target chip using IdfCommand
        if project_path.exists() {
            let result = IdfCommand::new("set-target")
                .arg(target)
                .project_path(&project_path)
                .timeout_secs(120)
                .execute(config).await?;

            if !result.success {
                return Err(format!("Failed to set target '{}': {}", target, result.stderr));
            }
        }

        // Generate suggested actions for project creation
        let suggested_actions = generate_suggested_actions(
            "create",
            true,
            &SuggestionContext::new(),
        );

        Ok(ToolOutput {
            status: ToolStatus::Success,
            action_taken: "create".to_string(),
            data: serde_json::json!({
                "project_name": project_name,
                "project_path": project_path.to_string_lossy(),
                "target": target,
                "template": template,
            }),
            summary: format!("Created project '{}' [{}] from {}", project_name, target, template),
            details: Some(format!("Project path: {}", project_path.display())),
            state_delta: super::session_state::StateDelta::none(),
            suggested_actions,
            error: None,
        })
    }

    async fn validate_project(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        let project_path = args.get("project_path")
            .and_then(|v| v.as_str())
            .map(|s| std::path::PathBuf::from(s))
            .ok_or("Missing project_path parameter")?;

        if !project_path.exists() {
            return Err(format!("Project path does not exist: {}", project_path.display()));
        }

        let mut issues = Vec::new();
        let mut valid = true;

        // Check for CMakeLists.txt
        if !project_path.join("CMakeLists.txt").exists() {
            issues.push("Missing CMakeLists.txt".to_string());
            valid = false;
        }

        // Check for main/ directory
        if !project_path.join("main").exists() {
            issues.push("Missing main/ directory".to_string());
            valid = false;
        }

        // Check for sdkconfig
        if !project_path.join("sdkconfig").exists() {
            issues.push("Missing sdkconfig (run 'idf.py reconfigure')".to_string());
        }

        if valid {
            Ok(ToolOutput::success(
                format!("Project '{}' is valid", project_path.display()),
                serde_json::json!({
                    "valid": true,
                    "project_path": project_path.to_string_lossy(),
                }),
            ))
        } else {
            Ok(ToolOutput {
                status: ToolStatus::PartialSuccess,
                action_taken: "validate".to_string(),
                data: serde_json::json!({
                    "valid": false,
                    "issues": issues,
                }),
                summary: format!("Project has {} issues", issues.len()),
                details: Some(issues.join("\n")),
                state_delta: super::session_state::StateDelta::none(),
                suggested_actions: vec![],
                error: None,
            })
        }
    }
}
