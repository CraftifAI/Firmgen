use std::collections::HashMap;
use std::sync::Arc;
use async_trait::async_trait;
use serde_json::Value;
use tokio::sync::Mutex as AMutex;
use tokio::process::Command;
use std::process::Stdio;

use crate::at_commands::at_commands::AtCommandsContext;
use crate::tools::tools_description::{Tool, ToolDesc, ToolParam, ToolSource, ToolSourceType};
use crate::call_validation::{ChatMessage, ChatContent, ContextEnum};

use super::config::ESP32Config;
use super::output_protocol::ToolOutput;
use super::idf_command::{IdfCommand, infer_project_path, list_serial_ports as get_serial_ports};
use super::global_state::{get_config, get_state, get_state_mut, generate_suggested_actions, SuggestionContext};
use super::board_definition::BoardDefinition;
use super::session_state::DeviceConnection;
use std::time::Instant;

pub struct ESP32Device {
    pub config_path: String,
}

#[async_trait]
impl Tool for ESP32Device {
    fn as_any(&self) -> &dyn std::any::Any { self }

    fn tool_description(&self) -> ToolDesc {
        ToolDesc {
            name: "esp32_device".to_string(),
            display_name: "ESP32 Device".to_string(),
            source: ToolSource {
                source_type: ToolSourceType::Builtin,
                config_path: self.config_path.clone(),
            },
            agentic: true,
            experimental: false,
            description: "Interact with ESP32 devices. Operations: detect (find connected devices, auto-verifies if board_id set), verify (validate device - automatically uses board_id from --board-definition CLI if set, no board_id parameter needed), flash (program firmware), monitor (capture serial output), erase (erase flash), info (get chip information). For board-specific details (GPIO, pinouts, examples), use search_semantic tool with board_id in scope.".to_string(),
            parameters: vec![
                ToolParam {
                    name: "operation".to_string(),
                    param_type: "string".to_string(),
                    description: "Operation: 'detect' (find devices), 'verify' (validate device vs board_id), 'flash' (program firmware), 'monitor' (serial monitor), 'erase' (erase flash), 'info' (chip info)".to_string(),
                },
                ToolParam {
                    name: "port".to_string(),
                    param_type: "string".to_string(),
                    description: "Serial port (e.g., /dev/ttyUSB0). Auto-detected if not specified.".to_string(),
                },
                ToolParam {
                    name: "board_id".to_string(),
                    param_type: "string".to_string(),
                    description: "Board ID for verification (e.g., esp32-s3-devkitc-1-n32r8v). NOT NEEDED if --board-definition was set at startup - will use session board_id automatically. Only provide if you want to override the session board_id.".to_string(),
                },
                ToolParam {
                    name: "project_path".to_string(),
                    param_type: "string".to_string(),
                    description: "Path to ESP32 project (for 'flash' and 'monitor' operations)".to_string(),
                },
                ToolParam {
                    name: "baud_rate".to_string(),
                    param_type: "integer".to_string(),
                    description: "Serial baud rate (default: 115200)".to_string(),
                },
                ToolParam {
                    name: "duration".to_string(),
                    param_type: "integer".to_string(),
                    description: "Monitor duration in seconds (for 'monitor' operation, default: 10)".to_string(),
                },
            ],
            parameters_required: vec!["operation".to_string()],
        }
    }

    async fn tool_execute(
        &mut self,
        _ccx: Arc<AMutex<AtCommandsContext>>,
        tool_call_id: &String,
        args: &HashMap<String, Value>,
    ) -> Result<(bool, Vec<ContextEnum>), String> {
        let operation = args.get("operation")
            .and_then(|v| v.as_str())
            .ok_or("Missing required parameter: operation")?;

        // Use global config (cached, configurable via env var)
        let config = get_config().await?;

        let output = match operation {
            "detect" => self.detect_devices(&config).await?,
            "verify" => self.verify_device(&config, args).await?,
            "flash" => self.flash_device(&config, args).await?,
            "monitor" => self.monitor_device(&config, args).await?,
            "erase" => self.erase_flash(&config, args).await?,
            "info" => self.get_chip_info(&config, args).await?,
            _ => return Err(format!("Unknown operation: {}", operation)),
        };

        let context_files = vec![ContextEnum::ChatMessage(ChatMessage {
            role: "tool".to_string(),
            content: ChatContent::SimpleText(output.to_llm_context()),
            tool_calls: None,
            tool_call_id: tool_call_id.clone(),
            ..Default::default()
        })];

        Ok((false, context_files))
    }

    fn tool_depends_on(&self) -> Vec<String> {
        vec!["esp32".to_string()]
    }
}

impl ESP32Device {
    async fn detect_devices(&self, config: &ESP32Config) -> Result<ToolOutput, String> {
        // First, list available serial ports (cross-platform)
        let ports = get_serial_ports();
        
        let mut detected = Vec::new();
        
        // Try esptool auto-detection first (no port specified)
        let auto_result = IdfCommand::esptool("chip-id")
            .timeout_secs(10)
            .no_parse_errors()
            .execute(config).await;
        
        if let Ok(result) = auto_result {
            if result.success {
                let chip = self.parse_chip_type(&result.stdout);
                let port = self.extract_port_from_output(&result.stdout).unwrap_or("auto".to_string());
                
                detected.push(serde_json::json!({
                    "port": port,
                    "chip": chip,
                    "auto_detected": true,
                }));
            }
        }

        // Also try specific ports if auto-detect found nothing
        if detected.is_empty() {
            for port in &ports {
                let port_result = IdfCommand::esptool("chip-id")
                    .args(&["--port", port])
                    .timeout_secs(5)
                    .no_parse_errors()
                    .execute(config).await;
                
                if let Ok(result) = port_result {
                    if result.success {
                        let chip = self.parse_chip_type(&result.stdout);

                        // Avoid duplicates
                        if !detected.iter().any(|d| d.get("port").and_then(|p| p.as_str()) == Some(port.as_str())) {
                            detected.push(serde_json::json!({
                                "port": port,
                                "chip": chip,
                                "auto_detected": false,
                            }));
                        }
                    }
                }
            }
        }

        let devices_found = !detected.is_empty();
        let state = get_state().await;
        let board_id_set = state.session.board_id.is_some();
        drop(state);
        let suggested_actions = generate_suggested_actions(
            "detect",
            true,
            &SuggestionContext::new()
                .with_devices(devices_found)
                .with_board_id(board_id_set),
        );

        if detected.is_empty() {
            Ok(ToolOutput {
                status: super::output_protocol::ToolStatus::PartialSuccess,
                action_taken: "detect".to_string(),
                data: serde_json::json!({ 
                    "devices": [],
                    "available_ports": ports,
                }),
                summary: format!("No ESP32 devices detected. Available ports: {}", ports.join(", ")),
                details: Some("Ensure device is connected and in bootloader mode (hold BOOT button while connecting)".to_string()),
                state_delta: super::session_state::StateDelta::none(),
                suggested_actions,
                error: None,
            })
        } else {
            // Agentic: Get full device info, set active_device, and auto-verify if board_id is set
            let mut verification_result = None;
            let mut was_verified = false;
            
            // Get first detected device
            if let Some(first_device) = detected.first() {
                if let Some(port) = first_device.get("port").and_then(|p| p.as_str()) {
                    // Get full device info (chip, MAC, flash size)
                    let info_args = serde_json::json!({ "port": port });
                    if let Ok(info_output) = self.get_chip_info(config, &serde_json::from_value(info_args).unwrap_or_default()).await {
                        let info_data = info_output.data;
                        let chip = info_data.get("chip_type").and_then(|v| v.as_str()).unwrap_or("unknown").to_string();
                        let mac = info_data.get("mac_address").and_then(|v| v.as_str()).unwrap_or("unknown").to_string();
                        let flash_size = info_data.get("flash_size").and_then(|v| v.as_str()).unwrap_or("unknown").to_string();
                        
                        // Set active_device in session state
                        let mut state = get_state_mut().await;
                        state.session.active_device = Some(DeviceConnection {
                            port: port.to_string(),
                            chip: chip.clone(),
                            mac_address: mac.clone(),
                            flash_size: flash_size.clone(),
                            connected_at: Instant::now(),
                        });
                        let board_id = state.session.board_id.clone();
                        drop(state);
                        
                        // Auto-verify if board_id is set
                        if let Some(board_id) = board_id {
                            let verify_args = serde_json::json!({
                                "board_id": board_id,
                                "port": port,
                            });
                            match self.verify_device(config, &serde_json::from_value(verify_args).unwrap_or_default()).await {
                                Ok(verify_output) => {
                                    let verify_status = verify_output.status.clone();
                                    let verify_warnings = verify_output.data.get("warnings").cloned();
                                    verification_result = Some((verify_status, verify_warnings));
                                    
                                    // Mark as verified if verification succeeded
                                    match verify_output.status {
                                        super::output_protocol::ToolStatus::Success => {
                                            was_verified = true;
                                            let mut state = get_state_mut().await;
                                            state.session.mark_board_verified();
                                            drop(state);
                                        }
                                        _ => {} // PartialSuccess or other - don't mark as verified
                                    }
                                }
                                Err(e) => {
                                    tracing::warn!("Auto-verification failed (non-critical): {}", e);
                                }
                            }
                        }
                    }
                }
            }
            
            let mut data = serde_json::json!({ 
                "devices": detected,
                "available_ports": ports,
            });
            
            if let Some((status, warnings)) = verification_result {
                data["verification"] = serde_json::json!({
                    "status": format!("{:?}", status),
                    "warnings": warnings,
                });
            }
            
            // Add active_device and session board_id info if set
            let state = get_state().await;
            if let Some(active_dev) = &state.session.active_device {
                data["active_device"] = serde_json::json!({
                    "port": active_dev.port,
                    "chip": active_dev.chip,
                    "verified": state.session.board_verified,
                });
            }
            // Include session board_id so LLM knows it's available
            if let Some(ref bid) = state.session.board_id {
                data["session_board_id"] = serde_json::json!(bid);
                data["board_id_available"] = serde_json::json!(true);
            }
            drop(state);
            
            Ok(ToolOutput {
                status: super::output_protocol::ToolStatus::Success,
                action_taken: "detect".to_string(),
                data,
                summary: format!("Detected {} ESP32 device(s){}", 
                    detected.len(),
                    if was_verified { " and verified" } else { "" }),
                details: None,
                state_delta: super::session_state::StateDelta::none(),
                suggested_actions,
                error: None,
            })
        }
    }

    fn parse_chip_type(&self, output: &str) -> &'static str {
        // Order matters: check more specific / longer names first
        if output.contains("ESP32-P4") {
            "esp32p4"
        } else if output.contains("ESP32-S31") {
            "esp32s31"
        } else if output.contains("ESP32-S3") {
            "esp32s3"
        } else if output.contains("ESP32-S2") {
            "esp32s2"
        } else if output.contains("ESP32-C61") {
            "esp32c61"
        } else if output.contains("ESP32-C6") {
            "esp32c6"
        } else if output.contains("ESP32-C5") {
            "esp32c5"
        } else if output.contains("ESP32-C3") {
            "esp32c3"
        } else if output.contains("ESP32-C2") || output.contains("ESP8684") {
            "esp32c2"
        } else if output.contains("ESP32-H21") {
            "esp32h21"
        } else if output.contains("ESP32-H4") {
            "esp32h4"
        } else if output.contains("ESP32-H2") {
            "esp32h2"
        } else {
            // Fallback to classic ESP32
            "esp32"
        }
    }

    fn extract_port_from_output(&self, output: &str) -> Option<String> {
        // esptool prints "Serial port /dev/ttyUSB0" or similar
        for line in output.lines() {
            if line.contains("Serial port") {
                if let Some(port) = line.split_whitespace().last() {
                    return Some(port.to_string());
                }
            }
        }
        None
    }

    async fn flash_device(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        let port = args.get("port")
            .and_then(|v| v.as_str())
            .unwrap_or(&config.default_serial_port);

        // Infer project path
        let explicit_path = args.get("project_path").and_then(|v| v.as_str());
        let project_path = infer_project_path(explicit_path, None)
            .ok_or("No valid ESP-IDF project found")?;

        let baud_rate = args.get("baud_rate")
            .and_then(|v| v.as_u64())
            .unwrap_or(config.default_baud_rate as u64);

        // Check if build exists
        let build_dir = project_path.join("build");
        if !build_dir.exists() {
            return Err("Project not built. Run esp32_build with 'build' operation first.".to_string());
        }

        // Use IdfCommand for flash with proper environment setup
        let result = IdfCommand::new("flash")
            .args(&["-p", port, "-b", &baud_rate.to_string()])
            .project_path(&project_path)
            .timeout_secs(300)  // 5 minute timeout
            .execute(config).await?;

        if result.success {
            // Generate suggested actions for successful flash
            let suggested_actions = generate_suggested_actions(
                "flash",
                true,
                &SuggestionContext::new(),
            );

            Ok(ToolOutput {
                status: super::output_protocol::ToolStatus::Success,
                action_taken: "flash".to_string(),
                data: serde_json::json!({
                    "port": port,
                    "baud_rate": baud_rate,
                    "flash_time_seconds": result.duration.as_secs_f64(),
                    "project_path": project_path.to_string_lossy(),
                }),
                summary: format!("Flashed to {} in {:.1}s", port, result.duration.as_secs_f64()),
                details: None,
                state_delta: super::session_state::StateDelta::none(),
                suggested_actions,
                error: None,
            })
        } else {
            // Generate suggested actions for failed flash
            let suggested_actions = generate_suggested_actions(
                "flash",
                false,
                &SuggestionContext::new(),
            );

            let error = result.errors.first().cloned();

            Ok(ToolOutput {
                status: super::output_protocol::ToolStatus::Failed,
                action_taken: "flash".to_string(),
                data: serde_json::json!({
                    "port": port,
                    "error_count": result.errors.len(),
                }),
                summary: format!("Flash failed: {}", result.summary),
                details: Some(result.combined_output()),
                state_delta: super::session_state::StateDelta::none(),
                suggested_actions,
                error,
            })
        }
    }

    async fn monitor_device(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        let port = args.get("port")
            .and_then(|v| v.as_str())
            .unwrap_or(&config.default_serial_port);

        let project_path = args.get("project_path")
            .and_then(|v| v.as_str())
            .map(|s| std::path::PathBuf::from(s))
            .unwrap_or_else(|| std::path::PathBuf::from("."));

        let duration = args.get("duration")
            .and_then(|v| v.as_u64())
            .unwrap_or(10);

        let baud_rate = args.get("baud_rate")
            .and_then(|v| v.as_u64())
            .unwrap_or(config.default_baud_rate as u64);

        // Use pyserial with DTR/RTS reset logic (simpler approach, like original)
        // This adds the reset sequence that idf.py monitor does, but keeps the simple readline approach
        let python_script = format!(
            r#"
import serial
import sys
import time
import signal

def timeout_handler(signum, frame):
    sys.exit(0)

signal.signal(signal.SIGALRM, timeout_handler)
signal.alarm({})

try:
    # Open serial port
    ser = serial.Serial('{}', {}, timeout=1)
    
    # ESP32 reset sequence via DTR/RTS (triggers device reset)
    # Set both high, then both low to trigger reset
    ser.setDTR(True)
    ser.setRTS(True)
    time.sleep(0.1)
    ser.setDTR(False)
    ser.setRTS(False)
    time.sleep(0.5)  # Wait for device to boot after reset
    
    # Clear any buffered data
    ser.reset_input_buffer()
    
    # Read output for specified duration (original simple approach)
    start_time = time.time()
    while time.time() - start_time < {}:
        if ser.in_waiting > 0:
            line = ser.readline()
            if line:
                sys.stdout.write(line.decode('utf-8', errors='replace'))
                sys.stdout.flush()
        time.sleep(0.1)
    ser.close()
except Exception as e:
    sys.stderr.write(f"Error: {{e}}\n")
    sys.exit(1)
"#,
            duration + 2,  // Add 2s buffer for signal handling
            port,
            baud_rate,
            duration
        );

        let mut cmd = Command::new("python3");
        cmd.arg("-c");
        cmd.arg(&python_script);
        cmd.current_dir(&project_path);
        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        let _start_time = std::time::Instant::now();
        let output = tokio::time::timeout(
            std::time::Duration::from_secs(duration + 5),
            cmd.output()
        ).await
        .map_err(|_| format!("Monitor operation timed out after {}s", duration + 5))?
        .map_err(|e| format!("Failed to monitor device: {}", e))?;

        let stdout = String::from_utf8_lossy(&output.stdout);
        let stderr = String::from_utf8_lossy(&output.stderr);

        // Filter out any error messages that aren't actual serial data
        let filtered_output: String = stdout.lines()
            .filter(|line| {
                !line.trim().is_empty() &&
                !line.contains("Error:")  // Filter Python errors from output
            })
            .collect::<Vec<_>>()
            .join("\n");
        
        let details = if !filtered_output.is_empty() {
            Some(format!("STDOUT\n```\n{}\n```", filtered_output))
        } else if !stderr.is_empty() {
            Some(format!("STDERR\n```\n{}\n```", stderr))
        } else {
            Some("No output captured. Check device connection and baud rate.".to_string())
        };
        
        // Determine status based on whether we got output
        let status = if !filtered_output.is_empty() {
            super::output_protocol::ToolStatus::Success
        } else if output.status.success() {
            super::output_protocol::ToolStatus::PartialSuccess
        } else {
            super::output_protocol::ToolStatus::Failed
        };
        
        Ok(ToolOutput {
            status,
            action_taken: format!("monitor_device({})", port),
            data: serde_json::json!({
                "port": port,
                "duration": duration,
                "baud_rate": baud_rate,
                "output_length": filtered_output.len(),
                "lines": filtered_output.lines().count(),
            }),
            summary: format!("Captured {}s of output from {} ({} lines)", duration, port, filtered_output.lines().count()),
            details,
            state_delta: super::session_state::StateDelta::none(),
            suggested_actions: vec![],
            error: None,  // Error details are included in details field
        })
    }

    async fn erase_flash(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        let port = args.get("port")
            .and_then(|v| v.as_str())
            .unwrap_or(&config.default_serial_port);

        // Infer project path (allow explicit override like other operations)
        let explicit_path = args.get("project_path").and_then(|v| v.as_str());
        let project_path = infer_project_path(explicit_path, None)
            .ok_or("No valid ESP-IDF project found (CMakeLists.txt not found)")?;

        let result = IdfCommand::new("erase-flash")
            .args(&["-p", port])
            .project_path(&project_path)
            .timeout_secs(120)
            .execute(config).await?;

        if result.success {
            Ok(ToolOutput::success(
                format!("Erased flash on {}", port),
                serde_json::json!({ "port": port, "project_path": project_path.to_string_lossy() }),
            ))
        } else {
            Err(format!("Erase failed: {}", result.stderr))
        }
    }

    async fn get_chip_info(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        let port = args.get("port")
            .and_then(|v| v.as_str())
            .unwrap_or(&config.default_serial_port);

        // Get chip info using IdfCommand::esptool
        let chip_result = IdfCommand::esptool("chip-id")
            .args(&["--port", port])
            .timeout_secs(30)
            .no_parse_errors()
            .execute(config).await?;

        if !chip_result.success {
            return Err(format!("Failed to get chip info: {}", chip_result.stderr));
        }

        let stdout = &chip_result.stdout;
        
        // Parse structured info from chip-id output
        // Actual format: "Chip is ESP32-P4 (revision v1.0)"
        let mut chip_type = None;
        let mut revision = None;
        let mut features = None;
        let mut crystal_freq = None;
        let mut mac = None;

        for line in stdout.lines() {
            // Match: "Chip is ESP32-P4 (revision v1.0)" or "Chip type: ESP32-P4"
            if line.contains("Chip is") || line.starts_with("Chip type:") {
                if line.contains("Chip is") {
                    // Format: "Chip is ESP32-P4 (revision v1.0)"
                    if let Some(start) = line.find("Chip is") {
                        let rest = &line[start + "Chip is".len()..].trim();
                        if let Some(rev_pos) = rest.find("(revision") {
                            chip_type = Some(rest[..rev_pos].trim().to_string());
                            let rev_part = &rest[rev_pos..];
                            if let Some(v_start) = rev_part.find('v') {
                                if let Some(end) = rev_part[v_start..].find(')') {
                                    revision = rev_part.get(v_start..v_start+end).map(|s| s.to_string());
                                }
                            }
                        } else {
                            chip_type = Some(rest.to_string());
                        }
                    }
                } else if line.starts_with("Chip type:") {
                    // Fallback format: "Chip type: ESP32-P4"
                    if let Some(colon_pos) = line.find(':') {
                        let rest = &line[colon_pos + 1..].trim();
                        if let Some(rev_pos) = rest.find("(revision") {
                            chip_type = Some(rest[..rev_pos].trim().to_string());
                            let rev_part = &rest[rev_pos..];
                            if let Some(v_start) = rev_part.find('v') {
                                if let Some(end) = rev_part[v_start..].find(')') {
                                    revision = rev_part.get(v_start..v_start+end).map(|s| s.to_string());
                                }
                            }
                        } else {
                            chip_type = Some(rest.to_string());
                        }
                    }
                }
            } else if line.starts_with("Features:") {
                if let Some(colon_pos) = line.find(':') {
                    features = Some(line[colon_pos + 1..].trim().to_string());
                }
            } else if line.contains("Crystal is") || line.starts_with("Crystal frequency:") {
                // Format: "Crystal is 40MHz" or "Crystal frequency: 40MHz"
                if line.contains("Crystal is") {
                    if let Some(start) = line.find("Crystal is") {
                        crystal_freq = Some(line[start + "Crystal is".len()..].trim().to_string());
                    }
                } else if line.starts_with("Crystal frequency:") {
                    if let Some(colon_pos) = line.find(':') {
                        crystal_freq = Some(line[colon_pos + 1..].trim().to_string());
                    }
                }
            } else if line.starts_with("MAC:") && mac.is_none() {
                // Get the first MAC address (may appear multiple times)
                if let Some(colon_pos) = line.find(':') {
                    let mac_str = line[colon_pos + 1..].trim();
                    // Extract MAC address (format: XX:XX:XX:XX:XX:XX)
                    if mac_str.len() >= 17 {
                        mac = Some(mac_str.to_string());
                    }
                }
            }
        }

        // Try to get flash ID using IdfCommand
        let mut flash_id = None;
        let mut flash_manufacturer = None;
        let mut flash_device = None;
        let mut flash_size = None;
        
        if let Ok(flash_result) = IdfCommand::esptool("flash-id")
            .args(&["--port", port])
            .timeout_secs(30)
            .no_parse_errors()
            .execute(config).await
        {
            if flash_result.success {
                // Look for flash information
                // Format: "Manufacturer: c8", "Device: 4018", "Detected flash size: 16MB"
                for line in flash_result.stdout.lines() {
                    if line.contains("Flash ID:") {
                        if let Some(colon_pos) = line.find(':') {
                            flash_id = Some(line[colon_pos + 1..].trim().to_string());
                        }
                    } else if line.starts_with("Manufacturer:") {
                        if let Some(colon_pos) = line.find(':') {
                            flash_manufacturer = Some(line[colon_pos + 1..].trim().to_string());
                        }
                    } else if line.starts_with("Device:") {
                        if let Some(colon_pos) = line.find(':') {
                            flash_device = Some(line[colon_pos + 1..].trim().to_string());
                        }
                    } else if line.contains("Detected flash size:") {
                        if let Some(start) = line.find("Detected flash size:") {
                            flash_size = Some(line[start + "Detected flash size:".len()..].trim().to_string());
                        }
                    }
                }
            }
        }

        // Build summary with key info
        let mut summary_parts = Vec::new();
        if let Some(ref ct) = chip_type {
            summary_parts.push(ct.clone());
            if let Some(ref rev) = revision {
                summary_parts.push(format!("({})", rev));
            }
        }
        if let Some(ref f) = features {
            summary_parts.push(f.clone());
        }
        if let Some(ref cf) = crystal_freq {
            summary_parts.push(format!("{} crystal", cf));
        }
        if let Some(ref m) = mac {
            summary_parts.push(format!("MAC: {}", m));
        }
        
        let summary = if summary_parts.is_empty() {
            format!("Chip info from {}", port)
        } else {
            format!("Chip info from {}: {}", port, summary_parts.join(", "))
        };

        Ok(ToolOutput::success(
            summary,
            serde_json::json!({
                "port": port,
                "chip_type": chip_type,
                "revision": revision,
                "features": features,
                "crystal_frequency": crystal_freq,
                "mac_address": mac,
                "flash_id": flash_id,
                "flash_manufacturer": flash_manufacturer,
                "flash_device": flash_device,
                "flash_size": flash_size,
                "raw_output": stdout, // Keep raw for debugging
            }),
        ))
    }

    pub async fn verify_device(&self, config: &ESP32Config, args: &HashMap<String, Value>) -> Result<ToolOutput, String> {
        // Agentic: Use board_id from session state if not provided in args
        let board_id_from_args = args.get("board_id").and_then(|v| v.as_str());
        
        // Get board_id from session if not in args (async)
        let board_id = if let Some(bid) = board_id_from_args {
            Some(bid.to_string())
        } else {
            let state = get_state().await;
            state.session.board_id.clone()
        };
        
        let board_id = board_id.ok_or_else(|| {
            "Missing required parameter: board_id. Either provide it in the tool call or set it via --board-definition CLI argument.".to_string()
        })?;

        // Reuse get_chip_info to gather device data
        let info_output = self.get_chip_info(config, args).await?;
        let data = info_output.data.clone();

        // Fetch board definition
        let board_def = self.fetch_board_definition(&board_id).await?;

        // Normalize chip types for comparison
        let expected_chip = board_def.chip.chip_type.to_lowercase();
        let actual_chip_raw = data.get("chip_type")
            .and_then(|v| v.as_str())
            .unwrap_or("");
        
        // Normalize actual chip type (ESP32-S3 -> esp32s3, ESP32-P4 -> esp32p4, etc.)
        let actual_chip = Self::normalize_chip_type(actual_chip_raw);

        let mut warnings = Vec::new();
        if expected_chip != actual_chip {
            warnings.push(format!("Chip mismatch: expected {}, detected {} ({})", expected_chip, actual_chip, actual_chip_raw));
        }

        if let Some(ident) = &board_def.identification {
            if let Some(range) = &ident.flash_size_range {
                if let Some(actual_flash) = data.get("flash_size").and_then(|v| v.as_str()) {
                    if !range.iter().any(|s| actual_flash.contains(s)) {
                        warnings.push(format!("Flash size mismatch: expected {:?}, detected {}", range, actual_flash));
                    }
                }
            }
        }

        let status = if warnings.is_empty() {
            super::output_protocol::ToolStatus::Success
        } else {
            super::output_protocol::ToolStatus::PartialSuccess
        };

        // Include info about whether board_id came from session or args
        let board_id_source = if board_id_from_args.is_some() { "provided" } else { "session (from --board-definition)" };
        
        Ok(ToolOutput {
            status,
            action_taken: "verify".to_string(),
            data: serde_json::json!({
                "board_id": board_id,
                "board_id_source": board_id_source,
                "chip_type": data.get("chip_type"),
                "warnings": warnings,
            }),
            summary: if warnings.is_empty() {
                format!("Device verified for board {} (from {})", board_id, board_id_source)
            } else {
                format!("Device verified with warnings for board {} (from {})", board_id, board_id_source)
            },
            details: if warnings.is_empty() { None } else { Some(warnings.join("\n")) },
            state_delta: super::session_state::StateDelta::none(),
            suggested_actions: vec![],
            error: None,
        })
    }

    async fn fetch_board_definition(&self, board_id: &str) -> Result<BoardDefinition, String> {
        let state = get_state().await;
        let cache = &state.cache;

        // API URL for board definitions
        let api_url = std::env::var("REFACT_ESP32_CONFIG_URL")
            .unwrap_or_else(|_| "http://localhost:8002".to_string());
        let board_url = format!("{}/v1/boards/{}", api_url, board_id);

        cache.get_board_definition(board_id, async {
            let client = reqwest::Client::builder()
                .connect_timeout(std::time::Duration::from_secs(5))
                .timeout(std::time::Duration::from_secs(15))
                .build()
                .map_err(|e| format!("Failed to build HTTP client: {}", e))?;
            let response = client.get(&board_url)
                .send()
                .await
                .map_err(|e| format!("Failed to fetch board definition: {}", e))?;

            if !response.status().is_success() {
                return Err(format!("Server returned error: {}", response.status()));
            }

            let board_def: BoardDefinition = response.json()
                .await
                .map_err(|e| format!("Failed to parse board definition: {}", e))?;
            Ok(board_def)
        }).await
    }

    /// Normalize chip type string to match schema format
    fn normalize_chip_type(chip_type: &str) -> String {
        let normalized = chip_type.to_lowercase()
            .replace("esp32-", "esp32")
            .replace("esp32s3", "esp32s3")
            .replace("esp32s2", "esp32s2")
            .replace("esp32s31", "esp32s31")
            .replace("esp32c3", "esp32c3")
            .replace("esp32c6", "esp32c6")
            .replace("esp32c61", "esp32c61")
            .replace("esp32c5", "esp32c5")
            .replace("esp32c2", "esp32c2")
            .replace("esp32p4", "esp32p4")
            .replace("esp32h2", "esp32h2")
            .replace("esp32h4", "esp32h4")
            .replace("esp32h21", "esp32h21");
        
        // If still contains spaces or dashes, remove them
        normalized.replace("-", "").replace(" ", "").to_lowercase()
    }
}

