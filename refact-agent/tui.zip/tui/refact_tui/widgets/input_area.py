"""Chat input area with multi-line support, command handling, and @-completions."""
from __future__ import annotations

import asyncio
from typing import Optional, List, Callable, Awaitable

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import TextArea, Static, Button
from textual.containers import Horizontal
from textual.message import Message
from textual import events
from rich.text import Text


class ChatTextArea(TextArea):
    """TextArea variant where Enter submits the message instead of inserting a newline.

    Shift+Enter keeps the default behavior and inserts a newline.
    """

    def on_key(self, event: events.Key) -> None:
        """Intercept Enter BEFORE the TextArea internal key map inserts a newline.

        on_key fires before bindings/character insertion, so prevent_default()
        actually suppresses the '\n'. Shift+Enter arrives as key='shift+enter'
        and is already excluded by the check below.
        """
        if event.key != "enter":
            # Shift+Enter arrives as 'shift+enter', so it naturally falls through
            return

        text = self.text.strip()
        if not text:
            event.prevent_default()  # don't add blank newline
            return

        event.prevent_default()
        event.stop()

        # Walk up: ChatTextArea -> Horizontal (input-row) -> ChatInput
        chat_input = self.parent.parent if self.parent is not None else None
        if isinstance(chat_input, ChatInput):
            chat_input.post_message(ChatInput.Submitted(text))
        self.text = ""


class ChatInput(Widget):
    """Multi-line chat input with Enter to send."""

    DEFAULT_CSS = """
    ChatInput {
        height: auto;
        max-height: 4;
        dock: bottom;
    }
    """

    class Submitted(Message):
        """Fired when user submits input."""
        def __init__(self, text: str):
            super().__init__()
            self.text = text

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._completion_fn: Optional[Callable] = None

    def compose(self) -> ComposeResult:
        yield Horizontal(
            Static(Text.from_markup("[bold cyan]>[/] "), classes="input-prompt"),
            ChatTextArea(id="chat-textarea", language=None),
            Button("Send", id="send-btn", classes="send-button", variant="primary"),
            classes="input-row",
        )

    def on_mount(self):
        ta = self.query_one("#chat-textarea", ChatTextArea)
        ta.show_line_numbers = False
        ta.focus()

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Send button clicked — same logic as Enter."""
        if event.button.id != "send-btn":
            return
        ta = self.query_one("#chat-textarea", ChatTextArea)
        text = ta.text.strip()
        if not text:
            return
        ta.text = ""
        self.post_message(ChatInput.Submitted(text))
        ta.focus()

    def set_completion_fn(self, fn: Optional[Callable]):
        """Set the async function to call for @-command completions.
        fn(query, cursor_pos) -> dict with 'completions' and 'replace' keys.
        """
        self._completion_fn = fn

    def set_disabled(self, disabled: bool):
        ta = self.query_one("#chat-textarea", ChatTextArea)
        ta.read_only = disabled
        try:
            btn = self.query_one("#send-btn", Button)
            btn.disabled = disabled
        except Exception:
            pass

    def focus_input(self):
        ta = self.query_one("#chat-textarea", ChatTextArea)
        ta.focus()
